<?php

namespace PaysonAB\PaysonCheckout2\Model;
/**
 * Class Paysoncheckout2
 *
 * @package PaysonAB\PaysonCheckout2\Model
 */
class Paysoncheckout2 extends \Magento\Payment\Model\Method\AbstractMethod
{
 
    /**
     * Payment code
     *
     * @var string
     */
    protected $_code = 'paysoncheckout2';
}
