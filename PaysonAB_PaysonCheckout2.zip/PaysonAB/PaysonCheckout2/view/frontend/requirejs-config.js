var config = {
    "map": {
        "*": {
            "payson": "PaysonAB_PaysonCheckout2/js/payson",
        }
    }
};
